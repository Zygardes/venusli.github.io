import java.awt.Graphics;
import java.awt.Color;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

public class Screen extends JPanel implements KeyListener, ActionListener {	
	private static final int WINDOW_HEIGHT = 650;
	private static final int WINDOW_WIDTH = 1000;
	
	private int location;
	private BufferedImage bg1, bg2, bg3, bg11, bg12, bg13, bg21, bg22, bg23, bgN7; 
	private final int xShift = 90;
	private final int altarBoundLeft = 430, altarBoundRight = 570, fenceBound = 390;
	
	private Player player;
	private ArrayList <Item> groundItems;
	private ArrayList <Item> bagItems;
	private ArrayList <NPC> npcArray;
	private Item purpleEgg, goldShard, net, sword, moth, key, treasure; 
	private SwordBase swordBase;
	private Vines vines;
	
	private NPC netMerchant, shackWhisperer, observer;
	private Bag bag;
	private boolean bFirstDrawString = true; 
	private NPC currentNpc;
	private int questNumber;
	private boolean gotSword = false;
	private boolean gameStarted = false;
	private boolean gameOver = false;
	
	private BufferedImage startScreen, grass, fence, fence2, endScreen;
	
	private JButton startButton;
	
	public Screen ()	{
		setLayout(null);
		
		initButtons();
		
		questNumber = 1;
		location = 1;
		try {                
			bg1 = ImageIO.read(new File("backgrounds/moth/background1.png"));
			bg2 = ImageIO.read(new File("backgrounds/moth/background2.png"));
			bg3 = ImageIO.read(new File("backgrounds/moth/background3.png"));
			bg11 = ImageIO.read(new File("backgrounds/moth/background11.png"));
			bg12 = ImageIO.read(new File("backgrounds/moth/background12.png"));
			bg13 = ImageIO.read(new File("backgrounds/moth/background13.png"));
			bg21 = ImageIO.read(new File("backgrounds/moth/background21.png"));
			bg22 = ImageIO.read(new File("backgrounds/moth/background22.png"));
			bg23 = ImageIO.read(new File("backgrounds/moth/background23.png"));
			bgN7 = ImageIO.read(new File("backgrounds/moth/backgroundN7.png"));
			
			grass = ImageIO.read(new File("images/grass.png"));
			fence = ImageIO.read(new File("images/fence.png"));
			fence2 = ImageIO.read(new File("images/fence2.png"));
			startScreen = ImageIO.read(new File("images/startScreen.png"));
			endScreen = ImageIO.read(new File("images/endScreen.png"));
			
	       } catch (IOException ex) {
	            // handle exception...
	       }
		
		
		player = new Player(100,100);
		bag = new Bag();
		groundItems = new ArrayList<Item>();
		bagItems = new ArrayList<Item>();
		npcArray = new ArrayList<NPC>();
		// new Items
		purpleEgg = new PurpleEgg(200, 200, 11);
		goldShard = new GoldShard(300, 200, 11);
		net = new Net(0, 0, 0);
		swordBase = new SwordBase(400, 350, 21);
		vines = new Vines(0, 0, 13);
		
		sword = new Sword(swordBase.getX(), swordBase.getY(), 21);
		moth = new Moth(350, 250, 23);
		key = new Key(525, 500, 12);
		treasure = new Treasure(350, 100, -7);
		
		// new NPCs
		netMerchant = new NetMerchant(500, 40, 1);
		shackWhisperer = new ShackWhisperer(500, 70, 2);
		observer = new Observer(850, 330, 22);
		
		groundItems.add(purpleEgg);
		groundItems.add(goldShard);
		groundItems.add(moth);
		groundItems.add(key);
		groundItems.add(treasure);
		
		npcArray.add(netMerchant);
		npcArray.add(shackWhisperer);
		npcArray.add(observer);
		
		setFocusable(true);
		addKeyListener(this);
	}
	
	private void initButtons() {
		startButton = new JButton("Start");
		startButton.setBounds(450, 385, 100, 40);
		startButton.addActionListener(this);
		this.add(startButton);
	}

	private void setButtons() {
		startButton.setVisible(!gameStarted);
	}
	
	public Dimension getPreferredSize()	{
		return new Dimension(WINDOW_WIDTH, WINDOW_HEIGHT);
	}
	
	public void paintComponent(Graphics g)	{
		super.paintComponent(g);
		// Setting backgrounds
		if (location >= 1 && location <= 3)	{
			if (location == 1) {
				g.drawImage(bg1, 0, 0, null);
			}	else if (location == 2) {
				g.drawImage(bg2, 0, 0, null);
			}	else if (location == 3) {
				g.drawImage(bg3, 0, 0, null);
			}
		}	else if (location >= 11 && location <= 13)	{
			if (location == 11) {
				g.drawImage(bg11, 0, 0, null);
			}	else if (location == 12) {
				g.drawImage(bg12, 0, 0, null);
			}	else if (location == 13) {
				g.drawImage(bg13, 0, 0, null);
				if (vines.getCut()) {
					vines.drawMe(g);
				}
			}
			
		}	else if (location >= 21 && location <= 23)	{
			if (location == 21) {
				g.drawImage(bg21, 0, 0, null);
				swordBase.drawMe(g);
			}	else if (location == 22) {
				g.drawImage(bg22, 0, 0, null);
			}	else if (location == 23) {
				g.drawImage(bg23, 0, 0, null);
			}
		}	if (location == -7) {
			g.drawImage(bgN7, 0, 0, null);
		}
		
		for (NPC each : npcArray)	{
			if (each.isVisible() && location == each.getLocation()) {		// change NPC
				each.drawMe(g);
			}
		}
		
		player.drawMe(g);
		
		// Draw any additional images that float above the player
		
		for (Item each : groundItems)	{
			if (each.isVisible() == true && location == each.getLocation())	{
				each.drawMe(g);
			}
		}
		if (bagItems.contains(moth) && location == treasure.getLocation()) {
			treasure.setVisible(true);
		}
		
		if (location == 12) {
			g.drawImage(grass, 0, 0, null);
		}	else if (location == 13) {
			g.drawImage(fence, 0, 0, null);
			if (!vines.getCut()) {
				vines.drawMe(g);
			}
		}	else if (location == 22) {
			g.drawImage(fence2, 0, 0, null);
		}
		
		if (this.bFirstDrawString)	{
			g.drawString("", 0, 0);
			bFirstDrawString = false;
		}
		else	{
			for (NPC each : npcArray)	{
				if (each.drawTheString()) {
					Dialogue.drawDialogueBox(g);
					g.drawString(currentNpc.getDialogue(), Dialogue.getX() + 30, Dialogue.getY() + 30);
				}
			}
			
			if (Dialogue.bShouldWriteMessage()) {
				Dialogue.drawDialogueBox(g);
				g.drawString(Dialogue.getMessage(), Dialogue.getX() + 30, Dialogue.getY() + 30);
			}
		}
		
		
		if (bag.isVisible() == true)	{
			bag.drawMe(g);
			int factor = 0;
			for (Item each : bagItems)	{
				each.setX(bag.getX() + xShift * factor + 40);
				each.setY(bag.getY() + 20);
				each.setVisible(true);
				each.drawMe(g);
				factor++;
			}
		}
		
		Font questFont = new Font("Arial", Font.PLAIN, 20);
		g.setFont(questFont);
		g.setColor(Color.cyan);
		g.drawString("Quest " + questNumber, WINDOW_WIDTH - 120, 30);
		
		if (!gameStarted) {
			g.drawImage(startScreen, 0, 0, null);
		}
		if (gameOver) {
			g.drawImage(endScreen, 0, 0, null);
		}
	}
	
	// implement methods of the Keylistener
		public void keyPressed(KeyEvent e) {

			int kCode = e.getKeyCode();
			if (gameStarted)	{
				if (kCode == 37) { 
					player.moveRight();
				}	else if (kCode == 38) { // up
					player.moveUp();
				}   else if (kCode == 39) { // left
					player.moveLeft();
				}	else if (kCode == 40) { // down
					player.moveDown();
				}	else if (kCode == 77) { // menu
					if (!bag.isVisible()) {
						bag.setVisible(true);
					}	else	{
						bag.setVisible(false);
					}
					
				} 	else if (kCode == 80) { // cheat key
						if (questNumber == 1) {
							groundItems.remove(purpleEgg);
							groundItems.remove(goldShard);
							if (bagItems.contains(purpleEgg))	{
								bagItems.remove(purpleEgg);
							}
							if (bagItems.contains(goldShard))	{
								bagItems.remove(goldShard);
							}
							bagItems.add(net);
							netMerchant.setMessageIndex(2);
							questNumber = 2;
							questCompleteSound();
						}	
						else if (questNumber == 2) {
							gotSword = true;
							if (!bagItems.contains(sword))	{
								bagItems.add(sword);
								swordBase.changeAppearance(true);
							}
							Dialogue.setMessage(1);
							Dialogue.bSetWriteMessage(true);
							
							vines.setCut(true);
							vines.changeAppearance();
							bagItems.add(moth);
							for (Item each : bagItems) {
								if (each instanceof Moth) {
									((Moth)each).setTaken(true);
									((Moth) each).changeAppearance();
								}
							}

							groundItems.remove(moth);
							observer.setMessageIndex(3);
							questNumber = 3;
							questCompleteSound();
						}	
						else if (questNumber == 3) {
							questCompleteSound();
							gameOver = true;
							// Create a game over screen TM
						}
				}

			}
			
			repaint();

		}

		public void keyReleased(KeyEvent e) {
		}

		public void keyTyped(KeyEvent e) {

		}
	
	public void animate() {
		while (true) {
			// sleep some milliseconds before next animate step/refresh
			try {
				Thread.sleep(50); // milliseconds
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}
			
			
			// Can you take this item?
			if (bagItems.contains(net))	{
				moth.setTakeablility(true);
			}
			
			// Setting the borders (and the obstacle borders too)
			if (player.getX() + player.getWidth() > WINDOW_WIDTH)	{
				if (location == 3 || location == 13 || location == 23 ) {
					player.setX(WINDOW_WIDTH);
				}	else 	{
					player.setX(0);
					location ++;
				}
			}	else if (player.getX() < 0)	{
				if (location == 1 || location == 11 || location == 21) {
					player.setX(0);
				}	else 	{
					player.setX(WINDOW_WIDTH - player.getWidth());
					location --;
				}
			}	
			
			if (player.getY() + player.getHeight() > WINDOW_HEIGHT)	{
				if (location == 21 || location == 22 || location == 23 ) {
					player.setY(WINDOW_HEIGHT - player.getHeight());
				}	else 	{
					player.setY(0);
					location += 10;
				}
			}	else if (player.getY() < 0)	{
				if (location == 1 || location == 2) {
					player.setY(0);
				}	else 	{
					player.setY(WINDOW_HEIGHT - player.getHeight());
					location -= 10;
				}
			}
			
			
			// Special boundaries:
			if (location == 3)	{
				if ((player.getX() < 300 || player.getX() + player.getWidth() > 370) && player.getY() < 70)	{
					player.setY(71);
				}	else if ((player.getX() >= 300 && player.getX() + player.getWidth() <= 370) && player.getY() < 70) {
					if (!bagItems.contains(key)) {
						player.setY(71);
					}
				}
				
			}	else if (location == 12)	{
					if (player.getX() + player.getWidth() > 900 && player.getY() + player.getHeight() > fenceBound)	{
						player.setX(WINDOW_WIDTH - player.getWidth() - 101);
					}		
			}	else if (location == 13)	{
				if ( player.getX() < altarBoundLeft )	{
					if (player.getY() + player.getHeight() > fenceBound && player.getY() + player.getHeight() < fenceBound + player.getMovement() + 1) {
						player.setY(fenceBound - player.getHeight());
					}
				}	else if (player.getX() + player.getWidth() > altarBoundRight )	{
					if (player.getY() + player.getHeight() > fenceBound && player.getY() + player.getHeight() < fenceBound + player.getMovement() + 1) {
						player.setY(fenceBound - player.getHeight());
					}
				}
				if (player.getY() + player.getHeight() > fenceBound) {
					if (!vines.getCut()) {
						if (bagItems.contains(sword))	{
							vines.setCut(true);
							vines.changeAppearance();
						}
						else 	{
							player.setY(fenceBound - player.getHeight());
						}
					}
					if (player.getX() < altarBoundLeft)	{
						player.setX(altarBoundLeft);
					}	else if (player.getX() + player.getWidth() > altarBoundRight) {
						player.setX(altarBoundRight - player.getWidth());
					}
				}
						
			}	else if (location == 22 )	{	
				if (player.getX() + player.getWidth() > 900)	{
					player.setX(WINDOW_WIDTH - player.getWidth() - 101);
				}	
				if (player.getY() + player.getHeight() > 950)	{
					player.setY(WINDOW_HEIGHT - player.getHeight() - 51);
				}
			}	else if (location == 23)	{
				if ( player.getX() < altarBoundLeft )	{
					player.setX(altarBoundLeft);
				}	else if (player.getX() + player.getWidth() > altarBoundRight) {
					player.setX(altarBoundRight - player.getWidth());
				}
				if (player.getY() > 475)	{
					player.setY(475);
				}
			}	
			if (location == -7) {
				if (!bagItems.contains(moth))	{
					if (player.getX() < 300 ) {
						player.setX(300);
					}	else if (player.getX() + player.getWidth() > 370) {
						player.setX(369-player.getWidth());
					}	
					if (player.getY() < 440)	{
						player.setY(440);
					}
				}	else	{
					if (player.getX() < 300)	{
						if (player.getX() < 0) {
							player.setX(0);
						}	if (player.getY() + player.getHeight() > WINDOW_HEIGHT)	{
							player.setY(WINDOW_HEIGHT- player.getHeight());
						}
					}	else if (player.getX() + player.getWidth() > WINDOW_WIDTH) {
						player.setX(WINDOW_WIDTH - player.getWidth());
					}
					
				}
			}
			
			// Check collision with items
			Item holdingItem = null;
			for (Item each : groundItems)	{
				if (player.getX() + player.getWidth() >= each.getX() && player.getY() + player.getHeight() >= each.getY() && 
						player.getX() <= each.getX() + each.getWidth() && player.getY() <= each.getY() + each.getHeight() && 
						location == each.getLocation() && each.takeable())	{
						holdingItem = each;
						bagItems.add(each);
						itemGotSound();
						if (each instanceof Moth)	{
							((Moth)each).setTaken(true);
							((Moth) each).changeAppearance();
							questNumber = 3;
							questCompleteSound();
						}
						break;
					}
			}
			
			// Getting the sword in Quest 2
			if (location == 21 && 
					player.getX() + player.getWidth() >= swordBase.getX() && player.getY() + player.getHeight() >= swordBase.getY() && 
					player.getX() <= swordBase.getX() + swordBase.getWidth() && player.getY() <= swordBase.getY() + swordBase.getHeight() ) 
			{
				swordBase.changeAppearance(true);
				Dialogue.setMessage(1);
				Dialogue.bSetWriteMessage(true);
				if (!gotSword)	{
					bagItems.add(sword);
					gotSword = true;
				}

			}	else {
				Dialogue.bSetWriteMessage(false);
				
			}
			
			groundItems.remove(holdingItem);
			
			// NPC collision
			for (NPC each : npcArray)	{
				boolean bPurpleEggFound = false;
				boolean bGoldShardFound = false;
				if (location == each.getLocation() && 
						player.getX() + player.getWidth() >= each.getX() && player.getY() <= each.getY() + each.getHeight() && 
						player.getX() <= each.getX() + each.getWidth() )   // change NPC
				{
					each.setDrawNpcString(true);
					this.currentNpc = each;
					if (location == 1)	{
						if (bagItems.size() >= 2)	{
							for (Item item : bagItems)	{
								if (item instanceof PurpleEgg )	{
									bPurpleEggFound = true;
								}
								if (item instanceof GoldShard )	{
									bGoldShardFound = true;
								}
							}
							if (bPurpleEggFound && bGoldShardFound)	{
								this.currentNpc.setMessageIndex(2);
								bagItems.remove(purpleEgg);
								bagItems.remove(goldShard);
								bagItems.add(net);
								questNumber = 2;
								questCompleteSound();
								break;
							}
						}
					}
					
				}	else	{
					each.setDrawNpcString(false);
				}
			}
			
			// No more Moth Glow :(
			if (questNumber == 3) {
				try {         
					bg1 = ImageIO.read(new File("backgrounds/noMoth/background1.png"));
					bg2 = ImageIO.read(new File("backgrounds/noMoth/background2.png"));
					bg3 = ImageIO.read(new File("backgrounds/noMoth/background3.png"));
					bg11 = ImageIO.read(new File("backgrounds/noMoth/background11.png"));
					bg12 = ImageIO.read(new File("backgrounds/noMoth/background12.png"));
					bg13 = ImageIO.read(new File("backgrounds/noMoth/background13.png"));
					bg21 = ImageIO.read(new File("backgrounds/noMoth/background21.png"));
					bg22 = ImageIO.read(new File("backgrounds/noMoth/background22.png"));
					bg23 = ImageIO.read(new File("backgrounds/noMoth/background23.png"));
					bgN7 = ImageIO.read(new File("backgrounds/noMoth/backgroundN7.png"));
					
			       } catch (IOException ex) {
			            System.out.println(ex);
			       }
			}
			
			if (bagItems.contains(treasure))	{
				gameOver = true;
			}
			
			repaint();
		}
		
	}
	
	 void itemGotSound() {
		try {
			URL url = this.getClass().getClassLoader().getResource("sounds/itemGot.wav");
			Clip clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(url));
			clip.start();
		} catch (Exception exc) {
			exc.printStackTrace(System.out);
		}
	}
	
	void questCompleteSound() {
		try {
			URL url = this.getClass().getClassLoader().getResource("sounds/questComplete.wav");
			Clip clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(url));
			clip.start();
		} catch (Exception exc) {
			exc.printStackTrace(System.out);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if(e.getSource() == startButton) {
			gameStarted = true;
			setButtons();
		}
		
		repaint(); 
	}
}
