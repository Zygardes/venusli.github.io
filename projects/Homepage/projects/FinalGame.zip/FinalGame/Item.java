import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.WindowConstants;
import java.awt.Color;

public abstract class Item {
	
	private int x;
	private int y;
	private int width;
	private int height;
	public boolean visible;
	private int location;
	protected BufferedImage image;
	boolean takeability;
	
	public Item(int x, int y, int location, String fileName) {
		this.x = x;
		this.y = y;
		visible = true;
		this.location = location;

		try {                
			this.image = ImageIO.read(new File(fileName));
	       } catch (IOException ex) {
	            // handle exception...
	       }
		
		width = image.getWidth();
		height = image.getHeight();
	}
	
	public void drawMe(Graphics g) {
		 g.drawImage(getImage(), getX(), getY(), null);
		 
	}
	
	public int getX()	{
		return x;
	}
	
	public int getY()	{
		return y;
	}

	public int getHeight()	{
		return height;
	}
	
	public int getWidth()	{
		return width;
	}
	
	public void setX(int x)	{
		this.x = x;
	}
	
	public void setY(int y)	{
		this.y = y;
	}
	
	public void setVisible(boolean visible) {
		this.visible = visible;
	}
	
	public boolean isVisible() {
		return this.visible;
	}
	
	public int getLocation()	{
		return location;
	}
	
	public BufferedImage getImage() {
		return this.image;
	}
	
	public void setTakeablility(boolean b) {
		takeability = b;
	}
	
	public boolean takeable() {
		return takeability;
	}
}
