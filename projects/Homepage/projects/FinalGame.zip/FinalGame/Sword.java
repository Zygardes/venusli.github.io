import java.awt.Graphics;

public class Sword extends Item	{
	
	public Sword(int x, int y, int location) {
		super(x, y, location, "images/sword.png");
	}
	
	public void drawMe(Graphics g) {
		 g.drawImage(getImage(), getX(), getY(), null);
		 
	}
}