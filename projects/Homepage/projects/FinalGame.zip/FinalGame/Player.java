import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.WindowConstants;
import java.awt.Color;

import javax.imageio.ImageIO;

import java.awt.Color;

public class Player {
	private int x;
	private int y;
	private int width;
	private int height;
	private int movement = 20;
	private BufferedImage image; 
	
	public Player(int x, int y)	{
		this.x = x;
		this.y = y;

		try {                
			image = ImageIO.read(new File("images/player.png"));
	       } catch (IOException ex) {
	            // handle exception...
	       }
		
		width = image.getWidth();
		height = image.getHeight();
	}
	
	public void drawMe(Graphics g) {
		g.setColor(Color.black);
		g.drawImage(image, getX(), getY(), null);
	}
	
	public void moveUp()	{
		y = y - movement;
	}
	
	public void moveDown() {
		y = y + movement;
	}
	
	public void moveRight()	{
		x = x - movement;
	}
	
	public void moveLeft() {
		x = x + movement;
	}
	
	public int getX()	{
		return x;
	}
	public int getY()	{
		return y;
	}
	public int getWidth()	{
		return width;
	}
	public int getHeight()	{
		return height;
	}
	
	public void setX(int x)	{
		this.x = x;
	}
	
	public void setY(int y)	{
		this.y = y;
	}
	
	public int getMovement() {
		return movement;
	}
}
