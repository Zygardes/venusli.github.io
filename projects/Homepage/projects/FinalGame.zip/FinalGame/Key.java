import java.awt.Graphics;

public class Key extends Item	{
	
	
	public Key(int x, int y, int location) {
		super(x, y, location, "images/key.png");
		takeability = true;
	}
	
	public void drawMe(Graphics g) {
		 g.drawImage(getImage(), getX(), getY(), null);
		 
	}
	
	
}