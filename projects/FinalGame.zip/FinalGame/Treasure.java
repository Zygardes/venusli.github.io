import java.awt.Graphics;

public class Treasure extends Item	{
	
	
	public Treasure(int x, int y, int location) {
		super(x, y, location, "images/treasure.png");
		takeability = true;
		super.visible = false;
	}
	
	public void drawMe(Graphics g) {
		 g.drawImage(getImage(), getX(), getY(), null);
		 
	}
	
	
}