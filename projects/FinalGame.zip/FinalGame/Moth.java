import java.awt.Graphics;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Moth extends Item	{
	
	private boolean taken;
	
	public Moth(int x, int y, int location) {
		super(x, y, location, "images/Moth.png");
		takeability = false;
		taken = false;
	}
	
	public void drawMe(Graphics g) {
		 g.drawImage(getImage(), getX(), getY(), null);
		 
	}
	
	public void changeAppearance()	{
		if (taken) {
			try {                
				super.image = ImageIO.read(new File("images/smallMoth.png"));
		       } catch (IOException ex) {
		            // handle exception...
		       }
		}
		
	}
	
	public void setTaken(boolean b) {
		taken = b;
	}
}