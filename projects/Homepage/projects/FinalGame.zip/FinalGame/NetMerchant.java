import java.awt.Graphics;

public class NetMerchant extends NPC {

	public NetMerchant(int x, int y, int location) {
		super(x, y, location, "images/netMerchant.png");
		
	}

	@Override
	public String getDialogue() {
		// TODO Auto-generated method stub
		if (getMessageIndex() == 1) {
			return "I'm selling giant nets--only costs one purple and one yellow stone! A limited offer!!!";
		}	else if (getMessageIndex() == 2 || getMessageIndex() == 3)	{
			return "These are perfect, here's your net! Go and catch some giant butterflies or something, haha!";
		}
		return "";
		
	}
	
}
