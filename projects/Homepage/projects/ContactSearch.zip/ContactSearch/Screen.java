import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Screen extends JPanel implements ActionListener{
	
	private Contact[] contactList;
	
	private JTextPane allContactsPane;
	
	private JButton searchFirstButton;
	private JButton searchLastButton;
	private JButton searchUserButton;
	private JButton searchDomainButton;
	private JButton searchExtButton;
	
	private JTextField searchInput;
	private JTextPane resultsPane;
	
	public Screen() {
		
		this.setLayout(null);
		
		contactList = new Contact[10];
		contactList[0] = new Contact("John", "Brown", "johnbrown@gmail.com");
		contactList[1] = new Contact("Jen", "Kris", "jenkris@gmail.com");
		contactList[2] = new Contact("Jose", "Locks", "joselocks@yahoo.com");
		contactList[3] = new Contact("Maria", "Hastings", "mariah@yahoo.com");
		contactList[4] = new Contact("Venus", "Li", "100019539@mvla.net");
		contactList[5] = new Contact("Richard", "Wiliams", "rwill@yahoo.edu");
		contactList[6] = new Contact("Thomas", "Gray", "thomasg@gmail.com");
		contactList[7] = new Contact("Doris", "Wang", "doris_wang@gmail.com");
		contactList[8] = new Contact("Catlin", "Anderson", "canderson@yahoo.com");
		contactList[9] = new Contact("David", "Miller", "davidmiller@scu.edu");
		
		
		allContactsPane = new JTextPane();
		allContactsPane.setBounds(10, 350, 300, 300);
		this.add(allContactsPane);
		
		String contactStr = "";
		for(int i = 0; i<contactList.length; i++) {
			contactStr += contactList[i].toString() + "\n";
		}
		allContactsPane.setText(contactStr);
		
		//buttons
		searchFirstButton = new JButton("Search First Name");
		searchFirstButton.setBounds(180, 50, 180, 30);
		searchFirstButton.addActionListener(this);
		this.add(searchFirstButton);
		
		searchLastButton = new JButton("Search Last Name");
		searchLastButton.setBounds(180, 100, 180, 30);
		searchLastButton.addActionListener(this);
		this.add(searchLastButton);
		
		searchUserButton = new JButton("Search User Name");
		searchUserButton.setBounds(180, 150, 180, 30);
		searchUserButton.addActionListener(this);
		this.add(searchUserButton);
		
		searchDomainButton = new JButton("Search Domain Name");
		searchDomainButton.setBounds(180, 200, 180, 30);
		searchDomainButton.addActionListener(this);
		this.add(searchDomainButton);
		
		searchExtButton = new JButton("Search Extension Name");
		searchExtButton.setBounds(180, 250, 180, 30);
		searchExtButton.addActionListener(this);
		this.add(searchExtButton);
		
		searchInput = new JTextField();
		searchInput.setBounds(375, 50, 210, 30);
		this.add(searchInput);
		
		resultsPane = new JTextPane();
		resultsPane.setBounds(380, 350, 300, 300);
		this.add(resultsPane);
		
		this.setFocusable(true);
		
	}
	
	public Dimension getPreferredSize() {
		
		return new Dimension (800, 700);
	}

	public void paintComponent (Graphics g) {
		
		super.paintComponent(g);
		
		
	}
	
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == searchFirstButton)	
		{
			
			String searchResult = searchInput.getText();
			//
			
			String displayResults = "";
			for (int i = 0; i<contactList.length; i++) {
				String firstName = contactList[i].getFirstName();
				if(firstName.equals(searchResult)) {
					displayResults += contactList[i] + "\n";
				}
			}
			
			resultsPane.setText(displayResults);
		}
		
		
		if (e.getSource() == searchLastButton)	
		{
			
			String searchResult = searchInput.getText();
			
			String displayResults = "";
			for (int i = 0; i<contactList.length; i++) {
				String lastName = contactList[i].getLastName();
				if(lastName.equals(searchResult)) {
					displayResults += contactList[i] + "\n";
				}
			}
				
			resultsPane.setText(displayResults);
		}
		
		
		if (e.getSource() == searchUserButton)	
		{
			
			String searchResult = searchInput.getText();
			
			String displayResults = "";
			for (int i = 0; i<contactList.length; i++) {
				String userName = contactList[i].getUserName();
				if(userName.equals(searchResult)) {
					displayResults += contactList[i] + "\n";
				}
			}
				
			resultsPane.setText(displayResults);
		}
		
		
		if (e.getSource() == searchDomainButton)	
		{
			
			String searchResult = searchInput.getText();
			
			String displayResults = "";
			for (int i = 0; i<contactList.length; i++) {
				String domainName = contactList[i].getDomainName();
				if(domainName.equals(searchResult)) {
					displayResults += contactList[i] + "\n";
				}
			}
				
			resultsPane.setText(displayResults);
		}
		
		
		if (e.getSource() == searchExtButton)	
		{
			
			String searchResult = searchInput.getText();
			
			String displayResults = "";
			for (int i = 0; i<contactList.length; i++) {
				String extName = contactList[i].getExtName();
				if(extName.equals(searchResult)) {
					displayResults += contactList[i] + "\n";
				}
			}
				
			resultsPane.setText(displayResults);
		}
		
	}

}
