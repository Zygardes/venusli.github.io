import java.awt.Graphics;

public class PurpleEgg extends Item	{
	
	
	public PurpleEgg(int x, int y, int location) {
		super(x, y, location, "images/purpleEgg.png");
		takeability = true;
	}
	
	
}