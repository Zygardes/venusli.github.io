import java.awt.Color;
import java.awt.Graphics;

public class Bag {
	
	private int x;
	private int y;
	private int width;
	private int height;
	Color bagColor;
	
	private boolean visible;
	
	public Bag() {
		x = 450;
		y = 500;
		width = 500;
		height = 120;
		
		visible = false;
		bagColor = new Color(186, 186, 186);
	}
	
	public void drawMe(Graphics g) {
		g.setColor(bagColor);
		g.fillRect(x, y, width, height);
	}
	
	public void setVisible(boolean visible) {
		this.visible = visible;
	}
	
	public int getX()	{
		return x;
	}
	
	public int getY()	{
		return y;
	}
	
	public boolean isVisible() {
		return this.visible;
	}
}
