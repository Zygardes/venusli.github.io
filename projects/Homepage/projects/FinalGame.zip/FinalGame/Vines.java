import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.WindowConstants;
import java.awt.Color;

public class Vines {
	
	private int x;
	private int y;
	private int width;
	private int height;
	public boolean visible;
	private boolean cut;
	private int location;
	private BufferedImage image;
	
	public Vines(int x, int y, int location) {
		this.x = x;
		this.y = y;
		visible = true;
		this.location = location;
		cut = false;

		try {                
			this.image = ImageIO.read(new File("images/vines1.png"));
	       } catch (IOException ex) {
	            // handle exception...
	       }
		
		width = image.getWidth();
		height = image.getHeight();
	}
	
	public void drawMe(Graphics g) {
		 g.drawImage(image, getX(), getY(), null);
		 
	}
	
	public int getX()	{
		return x;
	}
	
	public int getY()	{
		return y;
	}

	public int getHeight()	{
		return height;
	}
	
	public int getWidth()	{
		return width;
	}
	
	public void setVisible(boolean visible) {
		this.visible = visible;
	}
	
	public int getLocation()	{
		return location;
	}

	public void changeAppearance()	{
		if (cut) {
			try {                
				this.image = ImageIO.read(new File("images/vines2.png"));
		       } catch (IOException ex) {
		            // handle exception...
		       }
		}
		
	}
	/*
	public String getDialogue() {
		// TODO Auto-generated method stub
		return "whoops.";
		
	}*/
	
	public boolean getCut() {
		return cut;
	}
	
	public void setCut(boolean c) {
		cut = c;
	}
}
