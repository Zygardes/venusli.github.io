import javax.imageio.ImageIO;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Random;
import java.awt.Font;

public class Screen extends JPanel implements KeyListener {
	static final int WINDOW_WIDTH = 1000;
	static final int WINDOW_HEIGHT = 700;

	private static final int SHIP_STARTING_X = 50;
	private static final int SHIP_STARTING_Y = 300;
	private static final Color SPACE_COLOR = new Color(11, 18, 30);
	private static final Color railing = new Color(91, 91, 91);
	private static final Color RAIL_COLOR = new Color(153, 153, 153);
	private static final Color window = new Color(255, 252, 173);
	private static final String FONT_NAME = "Comic Sans MS";

	private static final int[] REFRESH_RATE = { 20, 15, 10 };

	private Random rand = new Random();

	private Star[] stars;
	private BufferedImage backgroundImage1; 
	private BufferedImage backgroundImage2; 
	private BufferedImage backgroundImage3; 

	private Ship s1;
	private Projectile[] projs;
	private Enemy[] enemies;

	private int level = 0;

	private boolean bStart = false;
	private boolean bGameEnd = false;

	public Screen() {
		initUI();

	//	this.backgroundImage1 = this.getBackgroundImage("galaxy.png");
		try {
            backgroundImage1 = ImageIO.read(new File("bin/galaxy.png"));
            backgroundImage2 = ImageIO.read(new File("bin/jupiter.png"));
            backgroundImage3 = ImageIO.read(new File("bin/shootingStar.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
		//this.backgroundImage2 = this.getBackgroundImage("jupiter.png");
		//this.backgroundImage3 = this.getBackgroundImage("shootingStar.png");

		// sets focus and key listener
		setFocusable(true);
		addKeyListener(this);
	}

	private void initUI() {
		// init background stars
		this.stars = new Star[50];
		for (int i = 0; i < this.stars.length; i++) {
			this.stars[i] = new Star(rand);
		}
				
		// init ship
		this.s1 = new Ship(SHIP_STARTING_X, SHIP_STARTING_Y);
		
		// init projectiles
		this.projs = new Projectile[3]; 
		for (int i = 0; i < this.projs.length; i++) {
			this.projs[i] = new Projectile(SHIP_STARTING_X, SHIP_STARTING_Y);
		}				

		// init level 1 (enemies)
		level = 1;
		this.enemies = new Enemy[3];
		for (int i = 0; i < this.enemies.length; i++) {
			this.enemies[i] = new Enemy(rand);
		}
	}

	private void restartGame() {
		this.bGameEnd = false;
		initUI();
	}

	// required method to implement
	public Dimension getPreferredSize() {
		return new Dimension(WINDOW_WIDTH, WINDOW_HEIGHT);
	}

	public void animate() {

		while (true) {
			// sleep some milliseconds before next animate step/refresh
			try {
				Thread.sleep(REFRESH_RATE[level - 1]); // milliseconds
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}

			if (bStart && !bGameEnd) {
				// move stars ->
				for (Star star : this.stars) {
					star.move();
				}

				// move projectiles
				for (Projectile proj : projs) {
					if (proj.isVisible()) {
						proj.moveRight();
					}
				}

				// move all enemies and check collisions
				for (Enemy enemy : enemies) {
					enemy.move();
					enemy.checkIfHitbyProjectile(projs);
					if (enemy.hitShipOrLeftEdge(s1)) {
						s1.lossALife();
					}
				}
			}

			// repaint
			repaint();
		}
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		// draw background space
		g.setColor(SPACE_COLOR);
		g.fillRect(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
		
		// draw stars
		for (Star star : stars) { // for-each
			star.drawMe(g);
		}
		

		// draw rail
		g.setColor(RAIL_COLOR);
		g.fillRect(0, 0, 70, WINDOW_HEIGHT);
		g.setColor(railing);
		g.fillRect(50, 0, 10, WINDOW_HEIGHT);
		g.setColor(window);
		int x = 0;
		for (int i = 0; i<= 8; i++)
		{
			g.fillRect(5, 50 + x, 35, 45);
			x+= 80;
		}

		// draw ship
		s1.drawMe(g);

		// set color for words to draw
		g.setColor(Color.YELLOW);

		// Check if should end the game
		if (s1.getLives() == 0 || level > 2) {
			this.bGameEnd = true;

			// draw end game screen
			Font font1 = new Font(FONT_NAME, Font.PLAIN, 70);
			g.setFont(font1);
			if (s1.getLives() == 0) {
				g.drawString("Game Over. You lost.", 170, 250);
			} else {
				g.drawString("You won the game!", 200, 250);
			}

			Font font2 = new Font(FONT_NAME, Font.PLAIN, 30);
			g.setFont(font2);
			g.drawString("(Hit 's' key to restart the game)", 270, 350);
		}

		// Game ongoing
		if (!this.bGameEnd) {
			// draw background theme
			if (level == 1) {
				g.drawImage(backgroundImage1, WINDOW_WIDTH/2 - 80, WINDOW_HEIGHT/2 - 120, 200, 200, null);
			} else if (level == 2) {
				g.drawImage(backgroundImage2, WINDOW_WIDTH - 350, -150, 600, 600, null);
				g.drawImage(backgroundImage3, WINDOW_WIDTH - 350, 40, 80, 50, null);
				g.drawImage(backgroundImage3, WINDOW_WIDTH - 750, 330, 80, 50, null);
				g.drawImage(backgroundImage3, WINDOW_WIDTH - 450, 550, 80, 50, null);
				g.drawImage(backgroundImage3, WINDOW_WIDTH - 560, 400, 80, 50, null);
			}
	 	
			//g.drawImage(backgroundImage1, WINDOW_WIDTH/2 - 80, WINDOW_HEIGHT/2 - 120, 200, 200, null);

			// draw status
			Font font3 = new Font(FONT_NAME, Font.PLAIN, 20);
			g.setFont(font3);

			g.drawString("Level: " + (this.level <= 2 ? this.level : "2"), 10, 20); 
			g.drawString("Lives: " + s1.getLives(), WINDOW_WIDTH - 120, 20);


			// draw Projectiles
			int numProjsVisible = 0;			
			for (Projectile proj : projs) {
				if (proj.isVisible()) {
					proj.drawMe(g);
					numProjsVisible++;
				}
			}

			// draw enemies
			int numEnemiesLeft = 0;
			for (Enemy enemy : enemies) {
				if (enemy.isVisible()) {
					enemy.drawMe(g);
					numEnemiesLeft++;
				}
			}

			// if no enemies left && no projectiles invisible
			if (numEnemiesLeft == 0 && numProjsVisible == 0) {
				// move to level 2
				increaseLevel();
			}
			
		}
	}

	// implement methods of the Keylistener
	public void keyPressed(KeyEvent e) {
		// key code
		// http://www.cambiaresearch.com/articles/15/javascript-char-codes-key-codes
		if (!this.bStart) {
			this.bStart = true; // any key press will start the game
		}

		int kCode = e.getKeyCode();
		if (kCode == 38) { // up
			s1.moveUp();
		} else if (kCode == 40) { // down
			s1.moveDown();
		} else if (kCode == 32) { // spacebar
			// fire cannon to shoot a projectile
			fireCannon();
		} else if (kCode == 80) { // 'p' - cheat key
			// move to next level
			increaseLevel();
		} else if (kCode == 83) { // 's' - restart the game
			this.restartGame();
		}

		repaint();
	}

	private void increaseLevel() {
		level++;
		if (level == 2) {
			initLevel2();
		}
		else if (level > 3) {
			level = 3;
		}
	}

	private void initLevel2() {
		this.enemies = new Enemy[10];
		for (int i = 0; i < this.enemies.length; i++) {
			this.enemies[i] = new Enemy(rand);
		}
	}
	
	private void fireCannon() {
		if (!this.bGameEnd) {
			this.s1.playCannonSound();
			for (Projectile proj : projs) {
				if (!proj.isVisible()) {
					proj.setVisible(true);
					proj.setPosition(s1.getX(), s1.getY());
					break;
				}
			}
		}
	}

	private void drawBackgroundTheme(Graphics g) {		
		if (level == 1) {
			g.drawImage(backgroundImage1, WINDOW_WIDTH/2 - 80, WINDOW_HEIGHT/2 - 120, 200, 200, null);
		} else if (level == 2) {
			g.drawImage(backgroundImage2, WINDOW_WIDTH - 220, 40, 200, 200, null);
			g.drawImage(backgroundImage3, WINDOW_WIDTH - 350, 40, 80, 50, null);
		}
	}
/*
	private Image getBackgroundImage(String themeImgFile) {
		Image image = null;
		try {			
			URL url = this.getClass().getClassLoader().getResource(themeImgFile);
			image = javax.imageio.ImageIO.read(new File(url.getFile()));
		} catch (Exception exc) {
			exc.printStackTrace(System.out);
		}
		return image;
	}
	*/	
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub		
	}
}
