import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.WindowConstants;
import java.awt.Color;

public abstract class NPC	{
	private int x;
	private int y;
	private int width;
	private int height;
	private int message;
	public boolean visible;
	private BufferedImage image; 
	private int location; 
	private boolean bDrawNpcString; 
	
	public NPC(int x, int y, int location, String fileName) {
		this.x = x;
		this.y = y;
		visible = true;
		this.location = location;
		message = 1;
		
		try {                
			image = ImageIO.read(new File(fileName));
	       } catch (IOException ex) {
	            // handle exception...
	       }
		
		width = image.getWidth();
		height = image.getHeight();
	}
	
	public void drawMe(Graphics g) {
		g.drawImage(getImage(), getX(), getY(), null);
	}
	
	
	public int getX()	{
		return x;
	}
	
	public int getY()	{
		return y;
	}
	
	public int getWidth()	{
		return width;
	}
	public int getHeight()	{
		return height;
	}
	
	
	public void setX(int x)	{
		this.x = x;
	}
	
	public void setY(int y)	{
		this.y = y;
	}
	
	public void setVisible(boolean visible) {
		this.visible = visible;
	}
	
	public boolean isVisible() {
		return this.visible;
	}
	
	public int getLocation()	{
		return location;
	}
	
	public BufferedImage getImage() {
		return this.image;
	}
	
	public boolean drawTheString () {
		return bDrawNpcString;
	}
	
	public void setDrawNpcString(boolean set) {
		this.bDrawNpcString = set;
	}
	
	public abstract String getDialogue();
	
	public void setMessageIndex(int i) {
		message = i;
	}
	
	public int getMessageIndex()	{
		return message;
	}
}


