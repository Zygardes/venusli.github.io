public class Observer extends NPC {

	public Observer(int x, int y, int location) {
		super(x, y, location, "images/observer.png");
		
	}

	@Override
	public String getDialogue() {
		
		if (getMessageIndex() == 1 || getMessageIndex() == 2) {
			return "There's a beautiful light coming from over there...";
		}	else if (getMessageIndex() == 3)	{
			return "Oh...the light is gone...";
		}
		return "";
		
	}
	
}
