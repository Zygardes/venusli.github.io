import java.net.URL;
import java.util.Random;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.awt.Color;
import java.awt.Graphics;

public class Enemy {
	private int x;
	private int y;
	private Random rand;

	private int width;
	private int height;

	private Color green;
	private Color blue;
	private Color purple;
	private Color black;
	private boolean bHit = false;
	private boolean visible = true;

	public Enemy(Random rand) {
		this.rand = rand;

		this.initPosition();
		
		this.width = 50;
		this.height = 50;

		this.green = new Color(0, 255, 0);
		this.blue = new Color (81, 171, 255);
		this.purple = new Color (91, 50, 239);
		this.black = new Color (0,0,0);
	}

	private void initPosition() {
		this.x = rand.nextInt(100) + (Screen.WINDOW_WIDTH - 150);
		this.y = rand.nextInt(Screen.WINDOW_HEIGHT - 200) + 100;
	}
	
	public void drawMe(Graphics g) {
		if (visible) {
			g.setColor(green);
			g.fillRect(x, y, width, height);
			g.setColor(blue);
			g.fillOval(x+10, y+10, 30, 30);
			g.setColor(purple);
			g.fillOval(x+45, y, 25, 25);
			g.fillOval(x+90, y+30, 20, 20);
			g.fillOval(x+140, y+20, 10, 10);
			g.setColor(black);
			g.fillOval(x+15, y+20, 15, 15);
		}
	}
	
	public void move() {
		if (visible) {
			x -= 1;
			if (this.x >= 0) {
				y -= rand.nextInt(11) - 5; // move in Y of [-5, +5] range randomly				
			} else {
				// reset
				this.initPosition();
			}
		}
	}

	public void checkIfHitbyProjectile(Projectile[] projs) {
		if (visible) {
			for (Projectile p: projs) {
				// get projectile's x, y, width, and height
				int pX = p.getX();
				int pY = p.getY();
				int pWidth = p.getWidth();
				int pHeight = p.getHeight();
				
				// check if hit by projectile
				if (pX + pWidth >= this.x && pX <= this.x + this.width 
						&& pY + pHeight >= this.y && pY <= this.y + this.height) {
					playSound2();
					this.bHit = true;
					// make 'this' enemy disappear
					visible = false;
				}
			}
		}
	}

	public boolean hitShipOrLeftEdge(Ship s) {
		boolean bHit = false;
		if (visible) {
			// get ship's x, y, width, and height of the 
			int sX = s.getX();
			int sY = s.getY();
			int sWidth = s.getWidth();
			int sHeight = s.getHeight();

			// check if hit the ship
			if (sX + sWidth >= this.x && sX <= this.x + this.width 
					&& sY + sHeight >= this.y && sY <= this.y + this.height) {
				playSound3();
				bHit = true;				
				visible = false;	// make enemy disappear
			} else if (this.x <= 0) { 
				// hit left edge 
				playSound3();
				bHit = true;
				// enemy will re-emerge on the right side
			}
		}
		return bHit;
	}

	private void playSound2() {
		try {
			URL url = this.getClass().getClassLoader().getResource("enemy.wav");
			Clip clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(url));
			clip.start();
		} catch (Exception exc) {
			exc.printStackTrace(System.out);
		}
	}

	private void playSound3() {
		try {
			URL url = this.getClass().getClassLoader().getResource("loss_life.wav");
			Clip clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(url));
			clip.start();
		} catch (Exception exc) {
			exc.printStackTrace(System.out);
		}
	}

	public boolean isHit() {
		return bHit;
	}

	public boolean isVisible() {
		return visible;
	}
}
