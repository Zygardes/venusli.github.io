import java.util.Random;

import java.awt.Color;
import java.awt.Graphics;

public class Star {
	private int x;
	private int y;

	Random rand;

	private int width;
	private int height;

	private Color star;

	public Star(Random rand) {
		this.rand = rand;

		this.x = rand.nextInt(Screen.WINDOW_WIDTH) + 1;
		this.y = rand.nextInt(Screen.WINDOW_HEIGHT) + 1;

		this.width = 2;
		this.height = 2;
		
		this.star = new Color(255, 255, 255);
	}

	public void drawMe(Graphics g) {		
		g.setColor(star);
		g.fillRect(x, y, width, height);		
	}

	public void reset() {
		this.x = rand.nextInt(260) + 500;
		this.y = rand.nextInt(550) + 1;
	}
	
	public void move() {
		x -= 1;
		if (this.x<= 0) {
			this.x = 800;
		}
	}
}
