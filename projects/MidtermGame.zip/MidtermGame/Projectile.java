import java.awt.Color;
import java.awt.Graphics;

public class Projectile {
	private int x;
	private int y;
	
	private int width;
	private int height;
	
	private Color gray;
	public boolean visible;
	
	
	public Projectile(int x, int y)	{		
		this.x = x;
		this.y = y;
		
		this.width = 20;
		this.height = 20;
		
		this.gray = new Color(107, 107, 107);
		this.visible = false;		
	}	
	
	public void drawMe(Graphics g) {		
		if ( visible )	{
			g.setColor(gray);
			g.fillOval(x, y, width, height);
		}		
	}
	
	public void moveRight() {
		if ( visible )	{
			x += 12;	// make it faster to hit the wall on the right.
		}
		
		if (x > Screen.WINDOW_WIDTH)	{
			visible = false;
		}
		
	}
	
	public void setVisible(boolean visible) {
		this.visible = visible;
	}
	
	public boolean isVisible() {
		return this.visible;
	}

	public void setPosition(int x, int y)	{
		if ( visible )	{
			this.x = x;
			this.y = y;
		}
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public int getWidth() {
		return width;
	}
	
	public int getHeight() {
		return height;
	}
}
