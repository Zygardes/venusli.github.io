import java.awt.Graphics;
import java.awt.Color;
import java.util.ArrayList;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

public class Table extends JPanel implements ActionListener {

	private Card[] deck;
	private Card[] selectedCards;

	private int playerIndex;

	private int points;
	private int totalCardsValue;
	private int payout;

	private boolean isGameOver = false;

	private JButton startButton;
	private JButton hitButton;
	private JButton standButton;

	public Table() {
		setLayout(null);

		initButtons();
		initCards();

		playerIndex = 0;

		selectedCards = new Card[9];

	}

	private void initButtons() {
		startButton = new JButton("New Game");
		startButton.setBounds(450, 50, 120, 40);
		startButton.addActionListener(this);
		this.add(startButton);

		hitButton = new JButton("Hit");
		hitButton.setBounds(350, 500, 100, 40);
		hitButton.addActionListener(this);
		this.add(hitButton);
		this.hitButton.setVisible(false);

		standButton = new JButton("Stand");
		standButton.setBounds(550, 500, 100, 40);
		standButton.addActionListener(this);
		this.add(standButton);
		this.standButton.setVisible(false);
	}

	private void initCards() {
		deck = new Card[52];

		for (int i = 0; i < 4; i++) {
			String cardName;
			int cardIndex = 0;

			if (i == 0) {
				cardName = Card.HEARTS;
			} else if (i == 1) {
				cardName = Card.SPADES;
			} else if (i == 2) {
				cardName = Card.DIAMONDS;
			} else {
				cardName = Card.CLUBS;
			}

			for (int j = 0; j < 9; j++) {
				cardIndex = i * 13 + j;
				int cardValue = j + 2;
				deck[cardIndex] = new Card(cardValue, String.valueOf(cardValue), cardName);
			}
			deck[++cardIndex] = new Card(10, "J", cardName);
			deck[++cardIndex] = new Card(10, "Q", cardName);
			deck[++cardIndex] = new Card(10, "K", cardName);
			deck[++cardIndex] = new Card(11, "A", cardName);
		}

		points = 20;
	}

	public Dimension getPreferredSize() {
		// Sets the size of the panel
		return new Dimension(1000, 600);
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		g.setColor(new Color(141, 175, 247));
		g.fillRect(0, 0, 1000, 600);

		g.setColor(Color.BLACK);
		Font font1 = new Font("Comic Sans MS", Font.PLAIN, 20);
		g.setFont(font1);

		g.drawString("Total Card Value: " + totalCardsValue, 750, 20);
		g.drawString("Points: " + points, 50, 20);

		int x = 100;
		int y = 300;
		for (int i = 0; i < this.playerIndex; i++) {
			selectedCards[i].drawMe(g, x, y);
			x += 80;
		}

		if (isGameOver) {
			Font font2 = new Font("Comic Sans MS", Font.PLAIN, 70);
			g.setFont(font2);
			if (totalCardsValue <= 21) {
				
				g.setColor(Color.BLACK);
				g.drawString("You win " + payout + " points!", 200, 250);
			} else {
				
				g.setColor(Color.RED);
				g.drawString("You lost the game", 200, 250);
			}
		}
		
		if (points < 1 && isGameOver) {
			g.drawString("Game Over!", 200, 150);
		}

	}

	private int calculateValue() {
		int sum = 0;
		for (int i = 0; i < playerIndex; i++) {
			sum += selectedCards[i].getValue();
		}
		return sum;
	}

	private void shuffle() {
		for (int i = deck.length - 1; i > 0; i--) {

			int rand = (int) (Math.random() * (i + 1));

			Card temp = deck[i];

			deck[i] = deck[rand];

			deck[rand] = temp;

		}
	}

	private boolean isGameEnded() {

		return this.totalCardsValue >= 21;
	}

	private void setButtons() {
		startButton.setVisible(isGameOver);
		hitButton.setVisible(!isGameOver);
		standButton.setVisible(!isGameOver);
	}

	private int getPayout() {
		int payout = 0;
		if (totalCardsValue >= 16 && totalCardsValue <= 18) {
			payout = 1;
		} else if (totalCardsValue == 19) {
			payout = 2;
		} else if (totalCardsValue == 20) {
			payout = 3;
		} else if (totalCardsValue == 21) {
			payout = 5;
		}

		return payout;
	}
	
	private void endGame()	{
		payout = getPayout();
		points += payout;
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == this.startButton && points > 0) {
			playSoundStart();
			points--;
			shuffle();
			playerIndex = 2;
			selectedCards[0] = deck[0];
			selectedCards[1] = deck[1];

			totalCardsValue = calculateValue();
			isGameOver = isGameEnded();
			if (isGameOver)	{
				endGame();
			}
			setButtons();

		}

		else if (e.getSource() == this.hitButton) {
			selectedCards[playerIndex] = deck[playerIndex];
			playerIndex++;

			totalCardsValue = calculateValue();
			isGameOver = isGameEnded();
			playSoundHit();
			if (isGameOver)	{
				endGame();	
				try {
					Thread.sleep(500);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if (totalCardsValue>21)	{
					playSoundLose();
				}	else	{
					playSoundWin();
				}
				
			}

			setButtons();
		}

		else if (e.getSource() == this.standButton) {
			isGameOver = true;
			playSoundStand();
			try {
				Thread.sleep(500);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			playSoundWin();
			endGame();
			setButtons();
		}

		repaint();
	}
	
	public void playSoundHit() {

		try {
			URL url = this.getClass().getClassLoader().getResource("bird.wav");
			Clip clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(url));
			clip.start();
		} catch (Exception exc) {
			exc.printStackTrace(System.out);
		}
	}
	
	public void playSoundStand() {

		try {
			URL url = this.getClass().getClassLoader().getResource("blip.wav");
			Clip clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(url));
			clip.start();
		} catch (Exception exc) {
			exc.printStackTrace(System.out);
		}
	}
	
	public void playSoundStart() {

		try {
			URL url = this.getClass().getClassLoader().getResource("bloop.wav");
			Clip clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(url));
			clip.start();
		} catch (Exception exc) {
			exc.printStackTrace(System.out);
		}
	}
	
	public void playSoundLose() {

		try {
			URL url = this.getClass().getClassLoader().getResource("blurp.wav");
			Clip clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(url));
			clip.start();
		} catch (Exception exc) {
			exc.printStackTrace(System.out);
		}
	}

	public void playSoundWin() {

		try {
			URL url = this.getClass().getClassLoader().getResource("start.wav");
			Clip clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(url));
			clip.start();
		} catch (Exception exc) {
			exc.printStackTrace(System.out);
		}
	}

}
