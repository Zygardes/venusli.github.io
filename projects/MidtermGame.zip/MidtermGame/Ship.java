import java.awt.Color;
import java.awt.Graphics;
import java.net.URL;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class Ship {
	private static final Color CANNON_COLOR = new Color(145, 145, 145);
	private static final Color railing = new Color(91, 91, 91);
	private static final int WIDTH = 50;
	private static final int HEIGHT = 50;
	private static final int UPPER_BOUND = Screen.WINDOW_HEIGHT - (HEIGHT + 5);
	
	private int x;
	private int y;
	private int width;
	private int height;
	
	private int lives = 3;
	
	public Ship(int x, int y) {
		this.x = x;
		this.y = y;
		this.width = WIDTH;
		this.height = HEIGHT;				
	}

	public void drawMe(Graphics g) {
		g.setColor(CANNON_COLOR);
		g.fillRect(x, y-16, width, height);
		g.fillRect(x, y, width * 3, height / 2);
	}

	public void moveUp() {
		y -= 15;
		if (y < 0) {
			y = 0;
		}
	}

	public void moveDown() {
		y += 15;
		if (y > UPPER_BOUND) {
			y = UPPER_BOUND;
		}
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}
	
	public int getWidth() {
		return width;
	}
	
	public int getHeight() {
		return height;
	}

	public void lossALife() {
		if (lives > 0) {
			lives -= 1;
		}
	}

	public int getLives() {
		return lives;
	}

	public void playCannonSound() {
		try {
			URL url = this.getClass().getClassLoader().getResource("cannon.wav");
			Clip clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(url));
			clip.start();
		} catch (Exception exc) {
			exc.printStackTrace(System.out);
		}
	}

}
