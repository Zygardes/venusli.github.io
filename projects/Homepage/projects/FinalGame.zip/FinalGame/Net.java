import java.awt.Graphics;

public class Net extends Item	{
	
	
	public Net(int x, int y, int location) {
		super(x, y, location, "images/net.png");
		
	}
	
	public void drawMe(Graphics g) {
		 g.drawImage(getImage(), getX(), getY(), null);
		 
	}
	
	
}