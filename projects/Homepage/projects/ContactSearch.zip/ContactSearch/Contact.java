public class Contact {
	private String firstName;
	private String lastName;
	private String userName;
	
	public Contact(String firstN, String lastN, String userN) {
		firstName = firstN;
		lastName = lastN;
		userName = userN;
	}
	
	public String toString() {
		String str = firstName + " " + lastName + " - " + userName;
		return str;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getUserName() {
		return userName.substring(0, userName.indexOf("@"));
	}
	
	public String getDomainName() {
		return userName.substring(userName.indexOf("@") + 1, userName.indexOf("."));
	}
	
	public String getExtName() {
		return userName.substring(userName.indexOf(".")+1, userName.length());
	}
	
}
