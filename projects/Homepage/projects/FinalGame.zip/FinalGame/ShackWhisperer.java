public class ShackWhisperer extends NPC {

	public ShackWhisperer(int x, int y, int location) {
		super(x, y, location, "images/shackWhisperer.png");
		
	}
	
	@Override
	public String getDialogue() {
		
		return "Meow. (There's an interesting shack over there, but it's locked...what could be in it...?)";
		
	}
	
}
