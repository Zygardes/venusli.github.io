import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class Dialogue {
	private static int x = 60;
	private static int y = 540;
	private static boolean bWriteMessage = false;
	private static int message = 0;
	private static final Font font1 = new Font("Comic Sans MS", Font.PLAIN, 20);
	
	public static String getMessage()	{
		
		if (message == 1)	{ //sword base message
			return "...Whoops.";
		}
		return "";
	}
	
	public static void bSetWriteMessage(boolean a) {
		bWriteMessage = a;
	}
	
	public static boolean bShouldWriteMessage()	{
		return bWriteMessage;
	}
	
	public static void drawDialogueBox(Graphics g) {
		g.setColor(Color.WHITE);
		g.fillRect(x, y, 900, 70);
		g.setFont(font1);
		g.setColor(Color.black);
		
	}
	
	public static int getX() {
		return x;
	}
	
	public static int getY() {
		return y;
	}
	
	public static void setMessage(int m) {
		message = m;
	}
	
}
