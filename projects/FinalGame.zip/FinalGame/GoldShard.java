import java.awt.Graphics;

public class GoldShard extends Item	{
	
	
	public GoldShard(int x, int y, int location) {
		super(x, y, location, "images/goldShard.png");
		takeability = true;
	}
	
	public void drawMe(Graphics g) {
		 g.drawImage(getImage(), getX(), getY(), null);
		 
	}
	
	
}